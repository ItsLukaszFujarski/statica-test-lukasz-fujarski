# statica-test-lukasz-fujarski

## Project setup
App created for Statica recruitment process. Created by Łukasz Fujarski @ 2024-02-09.

```
npm install
```

### To run the app use the following command
```
npm run serve
```

## Enter http://localhost:8080/ in your browser to see the app.

### Tech-Stack: Vue.js, SciChart, SASS, Axios, Tailwind
